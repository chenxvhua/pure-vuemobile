//index.js
//获取应用实例
const app = getApp()
var myCanvas = wx.createCanvasContext('myCanvas')
Page({
  data: {
    startPos:{
      x:0,
      y:0
    },
    pathArr: [],
    drawArr:[],
    isPreview:false,
    iconArr: [
      "icon-xiaoniao",
      "icon-jinzhuan",
      "icon-huahuaduoqingxin",
      "icon-tuiguangzhuanqianxian",
      "icon-xin",
      "icon-tubiaozhizuomoban",
      "icon-hongbao",
      "icon-jinyuanbao",
      "icon-gou"
    ],
    currentIcon:"icon-xiaoniao",
    currentIndex:0,
    win:wx.getSystemInfoSync(),
    animationData:{},
  },
  onLoad: function () {
    myCanvas.drawImage("../images/bg.jpg", 0, 0, this.data.win.windowWidth,this.data.win.windowHeight*0.9); 
    myCanvas.draw(true)

    var animation = wx.createAnimation({
      duration: 5000,
      timingFunction: 'ease',
    })

    this.animation = animation

    animation.scale(2, 2).rotate(45).step()

    this.setData({
      animationData: animation.export()
    })


  },
  start: function (e) {
    console.log("start")
    this.setData({
          startPos: {
              x: e.touches[0].x,
              y: e.touches[0].y
          }
     })
    this.handleAddPathArr(e)
  
  },
  move: function (e) {

    var tempDrawArr = [...this.data.drawArr]
    tempDrawArr.push({
      x: e.touches[0].x,
      y: e.touches[0].y
    })
  
    myCanvas.moveTo(this.data.startPos.x, this.data.startPos.y);
    tempDrawArr.forEach(function (item) {
      myCanvas.lineTo(item.x, item.y);
    })
    myCanvas.stroke();
    myCanvas.draw(true)

    this.setData({ drawArr: tempDrawArr})
    this.handleAddPathArr(e)
  
  },
  end: function (e) {
    console.log("end")

    this.setData({ drawArr:[] })
    this.handleAddPathArr(e)

  },
  handleAddPathArr(e){
    var temp = [...this.data.pathArr]
    if (e.touches.length) {
      temp.push({
        x: e.touches[0].x,
        y: e.touches[0].y
      });
    }
    this.setData({
      pathArr: temp
    })
  },
  handleBtn:function(e){
    var index = this.data.currentIndex;
    if (index >= this.data.iconArr.length){
      index=0;
    }
    else{
      index++;
    }
    if (this.data.isPreview){
      this.setData({ pathArr: [] })
      myCanvas.drawImage("../images/bg.jpg", 0, 0, this.data.win.windowWidth, this.data.win.windowHeight * 0.9);
      myCanvas.draw(true)
    }
     

     this.setData({ 
       isPreview: !this.data.isPreview,
       currentIndex: index, 
       currentIcon: this.data.iconArr[index] 
     })

  },
 

})
