// pages/dog/dog.js
var vtimer=null
var pathObj = { top: 0, fontSize: 5, boundWidth: 0, eqLeft: 0, animationData: {} }
var gTotal=0
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pathArr: [],
    blessWordanimationData:{},
    blessWordShow:false,
    blessWordBottomShow:false,
    settingShow:false,
    detail:false,//textarea兼容内边距
    containerShow:"",
    inputTitle:"祝狗年吉祥",
    inputContent:"旺狗贺岁，欢乐祥瑞\n旺狗汪汪，事业兴旺\n旺狗打滚，财源滚滚\n旺狗高跳，吉星高照\n旺狗撒欢，如意平安",
    itemsIconType: [
      { label: '金元宝', value: 'icon-zhifubaozhanneidaeshoufukuan' },
      { label: '单张人民币', value: 'singlermb' },
      { label: '一叠人民币', value: 'murmb' },
      { label: '一叠美元', value: 'dollar' },
      { label: '狗', value: 'dog' },
    ],
    blessItems: ["祝你一帆风顺，双龙戏珠", "三阳开泰，四季发财","九运当头，十全十美"],
    iconType:"dog",
    itemHide:"",
    win: wx.getSystemInfoSync(),
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this
    var curDate = new Date()
    var year = curDate.getFullYear()
    var month = curDate.getMonth()
    var day = curDate.getDay()
    var saveKey = year.toString() + month.toString() + day.toString()
    if (!wx.getStorageSync(saveKey)){
      wx.setClipboardData({
        data: 'LiDc2G48sk',
        success: function (res) {
          wx.setStorageSync(saveKey, "测试")
          wx.getClipboardData({
            success: function (res) {
              console.log("测试:" + res.data) // data
            }
          })
        }
      })
    }
    wx.showLoading({
      title:"初始化..."
    });
    console.log("options:", JSON.stringify(options));
    if (options.inputTitle || options.inputContent){
      var tempBlessItems = options.inputContent ? options.inputContent.split("\n") : that.data.blessItems
      var useBlessItems = tempBlessItems.filter(function (value) {
        return !!value
      })
      that.setData({
        "inputTitle": options.inputTitle ? options.inputTitle : that.data.inputTitle, 
        "inputContent": options.inputContent ? options.inputContent : that.data.inputContent,
         "blessItems": useBlessItems,
         "iconType": options.iconType ? options.iconType : that.data.options.iconType 
      },function(){
        that.resetStart()
        setTimeout(function () {
          wx.hideLoading();
          that.setData({ "containerShow": "container-show" })
        }, 1000)
      })
     
     
    }
    else{
      wx.hideLoading();
      that.setData({ "blessWordBottomShow": true, "blessWordShow": true })
    }
  },
  resetStart(){
    gTotal = 0
    var tempPathArr = []
    for (var i = 1; i <= 14; i++) {
      var tempPathObj = { ...pathObj }
      tempPathObj.fontSize = i * tempPathObj.fontSize
      tempPathArr.push(tempPathObj)
    }
    var detail = false
    if (wx.getSystemInfoSync().platform == 'ios') {
      detail = true
    }

    this.setData({ pathArr: tempPathArr, "itemHide":"", "detail": detail }, function () {
      this.handleQuene(0);
    }.bind(this))
  },
  handleQuene(setTopIndex){
        var that = this
        var query = wx.createSelectorQuery()
        query.selectAll('.item-size').boundingClientRect(function (nodeInfos) {
          var setTopPathArr = [...that.data.pathArr]
          var len = nodeInfos.length - 1
          //console.log("len:", len, "setTopIndex:", setTopIndex);
          for (var i = 0; i < nodeInfos.length;i++){
            //console.log("item:", JSON.stringify(item))
            if (setTopIndex < len) {
              var tempSetTopIndex = setTopIndex + 1
              //console.log("tempSetTopIndex:", tempSetTopIndex)
              if (setTopPathArr[tempSetTopIndex]) {
                setTopPathArr[tempSetTopIndex].top = nodeInfos[setTopIndex].height + nodeInfos[setTopIndex].top
              }
              if (setTopIndex>0){
                break;
              }
              else{
                pathObj.boundWidth = nodeInfos[0].width
                pathObj.eqLeft = that.data.win.windowWidth / 4
              }
            }
            if (setTopPathArr[i]) {
              setTopPathArr[i].boundWidth = nodeInfos[i].width
              //console.log("that.data.win.windowWidth:", that.data.win.windowWidth, "item.width:", item.width)
              setTopPathArr[i].eqLeft = that.data.win.windowWidth / 4
            }
          }
          that.setData({ pathArr: setTopPathArr },function(){
            //console.log("setTopPathArr:", setTopPathArr)
            setTopIndex++
            if (setTopIndex>=len){
                if (nodeInfos[setTopIndex-1].height + nodeInfos[setTopIndex-1].top > that.data.win.windowHeight){
                   var tempPathArr = [...that.data.pathArr]
                   tempPathArr.pop()
                   tempPathArr.unshift(pathObj)
                   that.setData({ pathArr: tempPathArr })
                }
                that.handleAninmal();
            }
            else{
                that.handleQuene(setTopIndex)
            }
             
          })
        })
        query.exec()
  },
  handleAninmal(){
    var that = this
    vtimer=setInterval(function () {
      clearInterval(vtimer)
      gTotal++
      //25 理想值
      if (gTotal > 25) {
        that.handleItemHide()
        return
      }
      var tempPathArr = that.data.pathArr.map(function (item) {
        var tempFontSize = item.fontSize
        tempFontSize++
        item.fontSize = tempFontSize
        return item
      })
      that.setData({ pathArr: tempPathArr }, function () {
        that.handleQuene(0)
      })
    }, 10)
  },
  handleItemHide(){
    var that = this
    that.setData({
      "itemHide": "item-hide"
    },function(){
       that.setData({ blessWordShow: true }, function () {
          setTimeout(function(){
            that.setData({ "blessWordBottomShow": true, "pathArr": []})
          },3000)
       })
    })

  },
  start: function (e) {
    console.log("start")
     return
  },
  move: function (e) {
    console.log("move")
    return
  },
  end: function (e) {
    console.log("end")
    return
  },

  handleSetting(){
    this.setData({
      "blessWordShow": false,"blessWordBottomShow":false,"settingShow": true })
  },
  handlePreview(){
     //blessItems
    var that=this
    var tempBlessItems = this.data.inputContent.split("\n")
    console.log(tempBlessItems)
    var useBlessItems = tempBlessItems.filter(function(value){
      return !!value
    })
    that.setData({ "blessItems": useBlessItems, "settingShow": false, "containerShow": "container-show" },function(){
      that.resetStart()
    })
  },
  handleTitleInput(e){
    this.setData({ "inputTitle": e.detail.value})
  },
  handleContentInput(e){
    this.setData({ "inputContent": e.detail.value })
  },
  iconTypeChange(e){
    this.setData({ "iconType": e.detail.value })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
   
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: "测试转发",
      path: "/pages/index/index?inputTitle=" + this.data.inputTitle+
       "&inputContent=" + this.data.inputContent+
        "&iconType=" + this.data.iconType,
      success: function (res) {
        console.log("成功:", JSON.stringify(res));
      },
      fail: function (res) {
        console.log("失败:", JSON.stringify(res));
      }
    }
  }
})